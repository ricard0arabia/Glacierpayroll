
<style>

img{
  display: block;
  width: 200px;
  height: 200px;
  margin-left: auto;
    margin-right: auto;
}
</style>
 <div class="row" style = "margin-left: -60px; margin-right: -60px; margin-top: -90px;">
       <div id="profile-page-sidebar" class="col s12 m4">
         <div class="card white">
            <div class="card-content white-text">
             
        
                  <img src="https://s-media-cache-ak0.pinimg.com/originals/3b/f0/77/3bf0775b0d234545d14a5941be966ab2.jpg" alt="" class="circle responsive-img"> <!-- notice the "circle" class -->
           
            </div>
             <div class="card-action">
              <a href="#">This is a link</a>
              <a href="#">This is a link</a>
            </div>
        
          </div>


        <!-- Profile About Details  -->
                <ul id="profile-page-about-details" class="collection z-depth-1">
                  <li class="collection-item">
                    <div class="row" style = "margin: 15px;">
                      <div class="col s5 grey-text darken-1"><i class="mdi-action-wallet-travel"></i> Name</div>
                      <div class="col s7 grey-text text-darken-4 right-align">Ricardo Arabia</div>
                    </div>
                  </li>
                  <li class="collection-item">
                    <div class="row"style = "margin: 15px;">
                      <div class="col s5 grey-text darken-1"><i class="mdi-social-poll"></i> Email</div>
                      <div class="col s7 grey-text text-darken-4 right-align">ricardo@yahoo.com</div>
                    </div>
                  </li>
                  <li class="collection-item">
                    <div class="row"style = "margin: 15px;">
                      <div class="col s5 grey-text darken-1"><i class="mdi-social-domain"></i> Telephone</div>
                      <div class="col s7 grey-text text-darken-4 right-align">9476515</div>
                    </div>
                  </li>
                    <li class="collection-item">
                    <div class="row"style = "margin: 15px;">
                      <div class="col s5 grey-text darken-1"><i class="mdi-social-cake"></i> Mobile</div>
                      <div class="col s7 grey-text text-darken-4 right-align">09278602341</div>
                    </div>
                  </li>
                  <li class="collection-item">
                    <div class="row"style = "margin: 15px;">
                      <div class="col s5 grey-text darken-1"><i class="mdi-social-cake"></i> Birth date</div>
                      <div class="col s7 grey-text text-darken-4 right-align">18th June, 1991</div>
                    </div>
                  </li>
                </ul>
                <!--/ Profile About Details  -->

                <!-- Profile About  -->
                <div class="card amber darken-2">
                  <div class="card-content white-text center-align">
                    <p class="card-title"><i class="mdi-social-group-add"></i> 3685</p>
                    <p>Followers</p>
                  </div>                  
                </div>
                <!-- Profile About  -->

                <!-- Profile feed  -->
                <ul id="profile-page-about-feed" class="collection z-depth-1">
                  <li class="collection-item avatar">
                    <img src="images/avatar.jpg" alt="" class="circle">
                    <span class="title">Project Title</span>
                    <p>Task assigned to new changes.
                      <br> <span class="ultra-small">Second Line</span>
                    </p>
                    <a href="#!" class="secondary-content"><i class="mdi-action-grade"></i></a>
                  </li>
                  <li class="collection-item avatar">
                    <i class="mdi-file-folder circle"></i>
                    <span class="title">New Project</span>
                    <p>First Line of Project Work 
                      <br> <span class="ultra-small">Second Line</span>
                    </p>
                    <a href="#!" class="secondary-content"><i class="mdi-social-domain"></i></a>
                  </li>
                  <li class="collection-item avatar">
                    <i class="mdi-action-assessment circle green"></i>
                    <span class="title">New Payment</span>
                    <p>Last UK Project Payment
                      <br> <span class="ultra-small">$ 3,684.00</span>
                    </p>
                    <a href="#!" class="secondary-content"><i class="mdi-editor-attach-money"></i></a>
                  </li>
                  <li class="collection-item avatar">
                    <i class="mdi-av-play-arrow circle red"></i>
                    <span class="title">Latest News</span>
                    <p>company management news
                      <br> <span class="ultra-small">Second Line</span>
                    </p>
                    <a href="#!" class="secondary-content"><i class="mdi-action-track-changes"></i></a>
                  </li>
                </ul>
                <!-- Profile feed  -->

            </div>



          <!--Preselecting a tab-->
        
    
         
              <div class="col s12 m8" style = "margin-top: 8px;">
                
                  <div class="col s12">
                    <ul class="tabs tab-demo-active z-depth-1  cyan ">
                      <li class="tab col s3"><a class="white-text waves-effect waves-light active" href="#201file">201 File</a>
                      </li>
                      <li class="tab col s3"><a class="white-text waves-effect waves-light " href="#activeone">Active One</a>
                      </li>
                      <li class="tab col s3"><a class="white-text waves-effect waves-light" href="#vestibulum">Vestibulum</a>
                      </li>
                    </ul>
                  </div>
                  <div class="col s12">




                <div id="201file" class="col s12 grey lighten-2">
                  <div class="card white">
                    <div class="card-content">
                      <div class = "row">
                          <form class="col s12">
                         
                          <div class = "panel-heading"><h5>Personal Information</h5></div> 
                              <div class="divider"></div>

                            <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="leI am not editab" id="disabled" type="text" class="validate">
                                <label for="disabled">Employee ID</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Birthdate</label>
                              </div>
                            </div>
                             <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Last Name</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Gender</label>
                              </div>
                            </div>
                             <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">First Name</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Marital Status</label>
                              </div>
                            </div>
                             <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Middle Name</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Active</label>
                              </div>
                            </div>
                            <!-- contact information -->

                               <div class = "panel-heading"><h5>Contact Information</h5></div> 
                              <div class="divider"></div>

                            <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="leI am not editab" id="disabled" type="text" class="validate">
                                <label for="disabled">Email </label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Country</label>
                              </div>
                            </div>
                             <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Telephone</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">City</label>
                              </div>
                            </div>
                             <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Mobile</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Zip Code</label>
                              </div>
                            </div>
                             <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Address</label>
                              </div>
                            </div>
                           


                        <div class = "panel-heading"><h5>Employment Details</h5></div> 
                              <div class="divider"></div>

                            <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="leI am not editab" id="disabled" type="text" class="validate">
                                <label for="disabled">Employment Type</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Department</label>
                              </div>
                            </div>
                             <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Position</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Rank</label>
                              </div>
                            </div>
                             <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Basic Salary</label>
                              </div>
                            </div>
                             <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Date Hired</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">Date Ended</label>
                              </div>
                            </div>

                        <div class = "panel-heading"><h5>Government Details</h5></div> 
                              <div class="divider"></div>

                            <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="leI am not editab" id="disabled" type="text" class="validate">
                                <label for="disabled">Tax Status</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">TIN</label>
                              </div>
                            </div>
                             <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">RDO</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">SSS</label>
                              </div>
                            </div>
                             <div class="row">
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">HDMF(Pag-IBIG | MID No./RTN)</label>
                              </div>
                              <div class="input-field col s6">
                                <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                                <label for="disabled">PhilHealth</label>
                              </div>
                            </div>
                           
                        </form>
                      </div>
                    </div>
                  </div>
                </div>







                    <div id="activeone" class="col s12  cyan lighten-4">
                      <dl>
                        <dt>Definition list</dt>
                        <dd>Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</dd>
                        <dt>Lorem ipsum dolor sit amet</dt>
                        <dd>Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</dd>
                      </dl>
                    </div>
                    <div id="vestibulum" class="col s12  cyan lighten-4">
                      <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies
                        mi vitae est. Mauris placerat eleifend leo.</p>
                    </div>
                  </div>
                </div>
           
           
            </div>