<?php
function tcpdf()
{
   
    require_once('tcpdf/tcpdf.php');
}
?>